const modal=document.getElementById("modal"), chat=document.getElementById("chat"), msg=document.getElementById("msg");
function openChat(title="🤖 AI Teacher"){document.getElementById("modalTitle").textContent=title;modal.style.display="block";msg.focus()}
function closeModal(){modal.style.display="none"}
async function send(){const text=msg.value.trim();if(!text)return;chat.innerHTML+=`<div class="bubble me">${esc(text)}</div><div class="bubble">⏳ Thinking...</div>`;msg.value="";chat.scrollTop=chat.scrollHeight;
try{const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text})});const d=await r.json();chat.lastElementChild.textContent=d.answer||d.error||"Something went wrong."}catch(e){chat.lastElementChild.textContent="Server connection error."}}
msg.addEventListener("keydown",e=>{if(e.key==="Enter")send()});
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function makeNotes(){openChat("📝 Smart Notes");msg.value="Make short revision notes for: ";msg.focus()}
function makeQuiz(){openChat("🧠 Quiz Maker");msg.value="Create a 10-question quiz on: ";msg.focus()}
async function solvePhoto(e){const f=e.target.files[0];if(!f)return;openChat("📸 Photo Solver");chat.innerHTML='<div class="bubble">⏳ Reading your question...</div>';const reader=new FileReader();reader.onload=async()=>{try{const r=await fetch("/api/vision",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({image:reader.result})});const d=await r.json();chat.innerHTML=`<div class="bubble">${esc(d.answer||d.error||"Could not solve.")}</div>`}catch(x){chat.innerHTML='<div class="bubble">Server connection error.</div>'}};reader.readAsDataURL(f)}
document.getElementById("theme").onclick=()=>document.body.classList.toggle("dark");