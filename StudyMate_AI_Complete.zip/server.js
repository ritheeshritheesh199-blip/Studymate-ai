require("dotenv").config();
const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
app.use(express.json({limit:"10mb"}));
app.use(express.static(path.join(__dirname,"public")));

const client = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;
const MODEL = process.env.OPENAI_MODEL || "gpt-5.6-luna";

const instructions = `You are StudyMate AI, a friendly AI teacher for school and college students.
Reply in the same language the student uses: English, Tamil, or Tanglish.
Explain simply, step-by-step. For maths/science, show working. Never pretend to know an answer; say when unsure.`;

app.post("/api/chat", async (req,res)=>{
  try {
    if(!client) return res.status(503).json({error:"AI is not connected yet. Add OPENAI_API_KEY on the server."});
    const prompt = String(req.body.message||"").trim();
    if(!prompt) return res.status(400).json({error:"Message is required"});
    const r = await client.responses.create({model:MODEL,instructions,input:prompt});
    res.json({answer:r.output_text||"Sorry, I couldn't generate an answer."});
  } catch(e){ res.status(500).json({error:e.message||"AI error"}); }
});

app.post("/api/vision", async (req,res)=>{
  try {
    if(!client) return res.status(503).json({error:"AI is not connected yet. Add OPENAI_API_KEY on the server."});
    const {image, question=""}=req.body;
    if(!image) return res.status(400).json({error:"Image is required"});
    const r = await client.responses.create({
      model:MODEL,
      instructions,
      input:[{role:"user",content:[
        {type:"input_text",text:question||"Solve this question from the image and explain step-by-step."},
        {type:"input_image",image_url:image}
      ]}]
    });
    res.json({answer:r.output_text||"I couldn't read the image clearly."});
  } catch(e){ res.status(500).json({error:e.message||"Vision error"}); }
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public/index.html")));
const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`StudyMate AI running on port ${PORT}`));